# MVRPD-TW — Tabu Search Solver

Bài toán VRP với K xe tải + D drone có ràng buộc Time Window.
Giải bằng Solomon I1 Construction + Tabu Search.

## Cài đặt
Không cần cài thêm thư viện. Chỉ cần Python 3.8+.

## Cách chạy

```bash
# Instance mẫu 10 khách hàng
python main.py

# File Solomon format
python main.py --file sample_solomon.txt --trucks 2 --drones 2 --range 60

# File custom format
python main.py --file sample_custom.txt --format custom

# So sánh các phương pháp construction
python main.py --compare

# Multi-start I1 (5 lần, lấy tốt nhất)
python main.py --multi-start 5

# Tùy chỉnh đầy đủ
python main.py --file c101.txt --trucks 3 --drones 2 \
               --range 80 --iter 1000 --tenure 12 --time 300
```

## Cấu trúc file

| File | Vai trò |
|------|---------|
| instance.py     | Đọc file đầu vào, lưu dữ liệu, precompute dist matrix |
| solution.py     | Biểu diễn nghiệm, Forward Time Slack O(1) |
| solomon_i1.py   | Solomon I1 Construction Heuristic (Solomon 1987) |
| tabu_search.py  | Thuật toán Tabu Search chính |
| construction.py | Greedy NN cũ (dự phòng) |
| main.py         | Entry point, CLI |

## Định dạng file đầu vào

### Solomon format (chuẩn benchmark VRPTW)
```
C101
VEHICLE  NUMBER  CAPACITY
         2       200
CUSTOMER  CUST  XCOORD  YCOORD  DEMAND  READY  DUE  SERVICE
          0     40.0    50.0     0       0     1236    0
          1     45.0    68.0    10     912      967   90
```

### Custom format (có cột C1/C2)
```
MY_INSTANCE
2  2  200  15  60.0
# id  x  y  demand  ready  due  service  type(0=C2, 1=C1)
0   40  50   0    0   1236   0
1   45  68  10  912    967  90   0
2   45  70  30  825    870  90   1
```

## Tham chiếu thuật toán
- Solomon (1987) — I1 Insertion Heuristic cho VRPTW
- Savelsbergh (1992) — Forward Time Slack, O(1) TW check
- Gendreau et al. (1994) — Tabu Search cho VRP
- Bräysy & Gendreau (2005) — Survey VRPTW construction heuristics
